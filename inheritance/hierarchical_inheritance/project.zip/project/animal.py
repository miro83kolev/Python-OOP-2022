class Animal:
    def eat(self):
        return 'eating...'