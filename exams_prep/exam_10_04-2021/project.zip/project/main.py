from project.controller import Controller

controller = Controller()
print(controller.add_aquarium('FreshwaterAquarium', 'Test'))