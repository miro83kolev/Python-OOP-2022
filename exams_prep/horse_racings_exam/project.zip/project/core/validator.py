class Validator:

    @staticmethod
    def check_if_string_is_empty_or_whitespace(string, message):
        if string.strip() == "":
            raise ValueError(message)

    @staticmethod
    def check_if_value_is_less_than_min_value(value, min_value, message):
        if value < min_value:
            raise ValueError(message)

    @staticmethod
    def checks_if_is_less_than_min_symbols(value, min_length, message):
        if len(value) < min_length:
            raise ValueError(message)

    @staticmethod
    def checks_if_speed_over_speed_limit(value, max_speed, message):
        if not value <= max_speed:
            raise ValueError(message)

    @staticmethod
    def check_if_valid_race_type(race_type, message):
        valid_race_types = ["Winter", "Spring", "Autumn", "Summer"]
        if race_type not in valid_race_types:
            raise ValueError(message)

    @staticmethod
    def check_if_valid_horse_type(horse_type):
        valid_horse_types = ["Appaloosa", "Thoroughbred"]
        if horse_type not in valid_horse_types:
            return False
        return True

    @staticmethod
    def raise_if_horse_name_exists(horses, horse_name, message):
        for horse in horses:
            if horse.name == horse_name:
                raise Exception(message)

    @staticmethod
    def raise_if_jockey_name_exists(jockeys, jockey_name, message):
        for jockey in jockeys:
            if jockey.name == jockey_name:
                raise Exception(message)

    @staticmethod
    def raise_if_race_type_exists(races, race_type, message):
        for race in races:
            if race.type == race_type:
                raise Exception(message)

    @staticmethod
    def find_jockey_by_name(jockeys, jockey_name, message):
        for jockey in jockeys:
            if jockey.name == jockey_name:
                return jockey
        raise Exception(message)

    @staticmethod
    def find_horse_by_type(horses, horse_type, message):
        for horse in horses:
            if horse.type == horse_type:
                return horse
        raise Exception(message)

    @staticmethod
    def find_race_by_type(races, type, message):
        for race in races:
            if race.type == type:
                return race
        raise Exception(message)

    @staticmethod
    def raise_if_not_enough_jockeys_in_race(race, min_jockey, message):
        if len(race.drivers) < min_jockey:
            raise Exception(message)




