from project.core.horse_factory import HorseFactory
from project.core.horse_race_factory import HorseRaceFactory
from project.core.jockey_factory import JockeyFactory
from project.core.validator import Validator


class HorseRaceApp:
    def __init__(self):
        self.horses = []
        self.jockeys = []
        self.horse_races = []

    def add_horse(self, horse_type: str, horse_name: str, horse_speed: int):
        if Validator.check_if_valid_horse_type(horse_type):
            Validator.raise_if_horse_name_exists(self.horses, horse_name, f'Horse {horse_name} has been already added!')
            horse = HorseFactory.create_horse(horse_type, horse_name, horse_speed)
            self.horses.append(horse)
            return f"{horse_type} horse {horse_name} is added."

    def add_jockey(self, jockey_name: str, age: int):
        Validator.raise_if_jockey_name_exists(self.jockeys, jockey_name, f'Jockey {jockey_name} has been already added!')
        jockey = JockeyFactory.create_jockey(jockey_name, age)
        self.jockeys.append(jockey)
        return f'Jockey {jockey_name} has been already added!'

    def create_horse_race(self, race_type: str):
        created_races = set()
        Validator.raise_if_race_type_exists(created_races, race_type, f'Race {race_type} has been already created!')
        race = HorseRaceFactory.create_horse_race(race_type)
        created_races.add(race)
        return f'Race {race_type} is created.'

    def add_horse_to_jockey(self, jockey_name: str, horse_type: str):
        jockey = Validator.find_jockey_by_name(self.jockeys, jockey_name, f"Jockey {jockey_name} could not be found!")
        horse = Validator.find_horse_by_type(self.horses, horse_type, f"Horse breed {horse_type} could not be found!")

        if jockey.horse is not None:
            return f'Jockey {jockey_name} already has a horse.'
        horse.is_taken = True
        jockey.horse = horse
        return f"Jockey {jockey_name} will ride the horse {horse.name}."

    def add_jockey_to_horse_race(self, race_type: str, jockey_name: str):
        jockey = Validator.find_jockey_by_name(self.jockeys, jockey_name, f"Jockey {jockey_name} could not be found!")
        race = Validator.find_race_by_type(self.horse_races, race_type, f'Race {race_type} could not be found!')

        if jockey.name in race.jockeys and jockey.horse is None:
            raise Exception(f'Jockey {jockey.name} cannot race without a horse!')

        if jockey.name in race.jockeys:
            return f'Jockey {jockey_name} has been already added to the {race_type} race.'

        race.jockeys.append(jockey)
        return f'Jockey {jockey_name} added to the {race_type} race.'

    def start_horse_race(self, race_type: str):
        race = Validator.find_race_by_type(self.horse_races, race_type, f'Race {race_type} could not be found!')
        Validator.raise_if_not_enough_jockeys_in_race(race_type, 2, 'Horse race {race_type} needs at least two participants!')

        racers = sorted(race.jockeys, key=lambda x: -x.horse.speed)
               
        output = ""

        for jockey in racers:
            output += f"The winner of the {race_type} race, with a speed of {max_speed}km/h is {jockey.name}! Winner's horse: {horse.name}."

        return output.strip()
