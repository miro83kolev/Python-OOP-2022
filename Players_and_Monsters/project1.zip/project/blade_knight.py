from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    def __init_(self, username, level):
        super().__init__(username, level)